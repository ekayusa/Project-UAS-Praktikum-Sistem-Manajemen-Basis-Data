<?php
try {
    // Membuat koneksi PDO
    $pdo = new PDO('mysql:host=localhost;dbname=sepatu', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Menampilkan informasi pembelian pelanggan
    $stmt = $pdo->prepare('SELECT * FROM view_customer_purchases');
    $stmt->execute();
    $customer_purchases = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Menampilkan pesan error jika terjadi kesalahan
    echo 'Error: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Purchases</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            color: #333;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        @media (max-width: 600px) {
            table, thead, tbody, th, td, tr {
                display: block;
            }
            thead tr {
                position: absolute;
                top: -9999px;
                left: -9999px;
            }
            tr {
                border: 1px solid #ccc;
                margin-bottom: 10px;
            }
            td {
                border: none;
                border-bottom: 1px solid #eee;
                position: relative;
                padding-left: 50%;
            }
            td:before {
                position: absolute;
                top: 50%;
                left: 10px;
                width: 45%;
                padding-right: 10px;
                white-space: nowrap;
                transform: translateY(-50%);
                font-weight: bold;
            }
            td:before { content: attr(data-label); }
        }
    </style>
</head>
<body>
    <h1>Customer Purchases</h1>
    <table>
        <thead>
            <tr>
                <th>Customer ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Sale Date</th>
                <th>Total Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($customer_purchases as $purchase): ?>
                <tr>
                    <td data-label="Customer ID"><?php echo htmlspecialchars($purchase['customer_id']); ?></td>
                    <td data-label="Name"><?php echo htmlspecialchars($purchase['customer_name']); ?></td>
                    <td data-label="Email"><?php echo htmlspecialchars($purchase['email']); ?></td>
                    <td data-label="Phone"><?php echo htmlspecialchars($purchase['phone']); ?></td>
                    <td data-label="Address"><?php echo htmlspecialchars($purchase['address']); ?></td>
                    <td data-label="Sale Date"><?php echo htmlspecialchars($purchase['sale_date']); ?></td>
                    <td data-label="Total Amount"><?php echo htmlspecialchars($purchase['total_amount']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
