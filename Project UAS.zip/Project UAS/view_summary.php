<?php
// Sertakan file koneksi ke database
include_once 'dbconection.php';

// Query untuk mengambil ringkasan penjualan dan pembayaran
$sql_summary = "SELECT s.id AS sale_id, c.NAME AS customer_name, s.sale_date, s.total_amount, p.payment_date, p.amount AS payment_amount, p.payment_method
                FROM sales s
                INNER JOIN customers c ON s.customer_id = c.id
                LEFT JOIN payments p ON s.id = p.sale_id";
$stmt_summary = $dbh->query($sql_summary);

// CSS Style untuk tabel
echo '<style>
        /* Aturan CSS untuk menyesuaikan tampilan tabel */
        .container {
            margin-top: 50px;
            width: 80%;
            margin: 0 auto;
        }
        .table {
            font-size: 16px;
            width: 100%;
            border-collapse: collapse;
        }
        .table th,
        .table td {
            color: #000; /* Warna font hitam */
            border: 1px solid #ddd; /* Garis tepi */
            padding: 8px;
            text-align: left;
        }
        .table th {
            background-color: #f2f2f2; /* Warna latar belakang header */
        }
        .table-striped tbody tr:nth-child(odd) {
            background-color: #f9f9f9; /* Warna latar belakang setiap baris ganjil */
        }
        .table-striped tbody tr:nth-child(even) {
            background-color: #fff; /* Warna latar belakang setiap baris genap */
        }
    </style>';

?>

<?php if ($stmt_summary->rowCount() > 0): ?>
    <div class="container">
        <h2>Summary of Sales and Payments</h2>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Sale ID</th>
                        <th>Customer Name</th>
                        <th>Sale Date</th>
                        <th>Total Amount</th>
                        <th>Payment Date</th>
                        <th>Payment Amount</th>
                        <th>Payment Method</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row_summary = $stmt_summary->fetch(PDO::FETCH_ASSOC)): ?>
                        <tr>
                            <td><?php echo $row_summary['sale_id']; ?></td>
                            <td><?php echo $row_summary['customer_name']; ?></td>
                            <td><?php echo $row_summary['sale_date']; ?></td>
                            <td><?php echo number_format($row_summary['total_amount'], 2); ?></td>
                            <td><?php echo $row_summary['payment_date']; ?></td>
                            <td><?php echo number_format($row_summary['payment_amount'], 2); ?></td>
                            <td><?php echo $row_summary['payment_method']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php else: ?>
    <div class="container">
        <p>No sales and payments found.</p>
    </div>
<?php endif; ?>
