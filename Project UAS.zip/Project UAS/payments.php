<?php
// Sertakan file koneksi ke database
include_once 'dbconection.php';

// Query untuk mengambil data payments
$sql_payments = "SELECT sales.id AS sale_id, payments.payment_date, payments.amount, payments.payment_method
                 FROM sales
                 INNER JOIN payments ON sales.id = payments.sale_id";
$stmt_payments = $dbh->query($sql_payments);

// CSS Style untuk tabel
echo '<style>
        /* Aturan CSS untuk menyesuaikan tampilan tabel */
        .container {
            margin-top: 50px;
            width: 80%;
            margin: 0 auto;
        }
        .table {
            font-size: 16px;
            width: 100%;
            border-collapse: collapse;
        }
        .table th,
        .table td {
            color: #000; /* Warna font hitam */
            border: 1px solid #ddd; /* Garis tepi */
            padding: 8px;
            text-align: left;
        }
        .table th {
            background-color: #f2f2f2; /* Warna latar belakang header */
        }
        .table-striped tbody tr:nth-child(odd) {
            background-color: #f9f9f9; /* Warna latar belakang setiap baris ganjil */
        }
        .table-striped tbody tr:nth-child(even) {
            background-color: #fff; /* Warna latar belakang setiap baris genap */
        }
    </style>';

?>

<div class="container">
    <h2>Payments</h2>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Sale ID</th>
                    <th>Payment Date</th>
                    <th>Amount</th>
                    <th>Payment Method</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row_payments = $stmt_payments->fetch(PDO::FETCH_ASSOC)): ?>
                    <tr>
                        <td><?php echo $row_payments['sale_id']; ?></td>
                        <td><?php echo $row_payments['payment_date']; ?></td>
                        <td><?php echo number_format($row_payments['amount'], 2); ?></td>
                        <td><?php echo $row_payments['payment_method']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <div style="margin-top: 20px;">
        <!-- Button untuk menampilkan detail pembayaran bersama dengan informasi penjualan -->
        <form action="view_payment_details.php" method="get" style="display: inline-block; margin-right: 10px;">
            <button type="submit" class="btn btn-primary">View Payment Details</button>
        </form>
        <!-- Button untuk menampilkan ringkasan penjualan dan pembayaran -->
        <!-- <form action="view_summary.php" method="get" style="display: inline-block;">
            <button type="submit" class="btn btn-primary">View Sales Summary</button>
        </form> -->
    </div>
</div>

