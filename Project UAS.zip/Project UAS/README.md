### Software yang di butuhkan : ###
* Apache (xampp)
* PHP (xampp) versi 5.4 atau lebih
* mysql (xampp)
* Text Editor
* dll

### Langkah -langkah Instalasi ###
* Buatlah database baru dengan nama terserah anda
* Import file yang ada di folder database yaitu shoes-store.sql ke database anda
* Ubahlah pengaturan user dan password database anda di dalam file dbconection.php
```
$dsn = 'mysql:dbname=db_shoes_store;host=localhost';
$user = 'root';
$password = '';
```

### Login ###
* user : admin
* pass : admin

Terima kasih