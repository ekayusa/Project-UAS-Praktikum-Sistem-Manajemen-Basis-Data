<?php
try {
    // Membuat koneksi PDO
    $pdo = new PDO('mysql:host=localhost;dbname=sepatu', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Menampilkan detail penjualan sepatu
    $stmt = $pdo->prepare('SELECT * FROM view_sales_details');
    $stmt->execute();
    $sales_details = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Menampilkan pesan error jika terjadi kesalahan
    echo 'Error: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Details</title>
</head>
<body>
    <h1>Sales Details</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Sales Detail ID</th>
                <th>Sale ID</th>
                <th>Customer Name</th>
                <th>Shoe ID</th>
                <th>Shoe Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Sale Date</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($sales_details as $detail): ?>
                <tr>
                    <td><?php echo htmlspecialchars($detail['sales_detail_id']); ?></td>
                    <td><?php echo htmlspecialchars($detail['sale_id']); ?></td>
                    <td><?php echo htmlspecialchars($detail['customer_name']); ?></td>
                    <td><?php echo htmlspecialchars($detail['shoe_id']); ?></td>
                    <td><?php echo htmlspecialchars($detail['shoe_name']); ?></td>
                    <td><?php echo htmlspecialchars($detail['quantity']); ?></td>
                    <td><?php echo htmlspecialchars($detail['price']); ?></td>
                    <td><?php echo htmlspecialchars($detail['sale_date']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
