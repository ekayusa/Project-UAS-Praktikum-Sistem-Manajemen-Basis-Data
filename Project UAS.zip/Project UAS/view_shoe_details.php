<?php
try {
    // Membuat koneksi PDO
    $pdo = new PDO('mysql:host=localhost;dbname=sepatu', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Menjalankan query untuk mengambil data dari view
    $stmt = $pdo->prepare('SELECT id, shoe_name, category_name, price, size, stock, comment, picture FROM view_shoe_details');
    $stmt->execute();
    
    // Mengambil hasil query sebagai array asosiatif
    $shoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Menampilkan pesan error jika terjadi kesalahan
    echo 'Error: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shoe Details</title>
</head>
<body>
    <h1>Shoe Details</h1>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Shoe Name</th>
                <th>Category Name</th>
                <th>Price</th>
                <th>Size</th>
                <th>Stock</th>
                <th>Comment</th>
                <th>Picture</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($shoes as $shoe): ?>
                <tr>
                    <td><?php echo htmlspecialchars($shoe['id']); ?></td>
                    <td><?php echo htmlspecialchars($shoe['shoe_name']); ?></td>
                    <td><?php echo htmlspecialchars($shoe['category_name']); ?></td>
                    <td><?php echo htmlspecialchars($shoe['price']); ?></td>
                    <td><?php echo htmlspecialchars($shoe['size']); ?></td>
                    <td><?php echo htmlspecialchars($shoe['stock']); ?></td>
                    <td><?php echo htmlspecialchars($shoe['comment']); ?></td>
                    <td><img src="images/product/<?php echo htmlspecialchars($shoe['picture']); ?>" width="100" alt="Shoe Image"></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
