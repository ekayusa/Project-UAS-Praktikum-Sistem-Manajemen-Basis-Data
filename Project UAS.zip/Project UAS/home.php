<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shoe Shop Record System</title>
    <link rel="stylesheet" href="css/nivo-slider.css" type="text/css" />
    <link rel="stylesheet" href="css/style.css" type="text/css" />
    <script type="text/javascript" src="js/jquery-1.4.3.min.js"></script>
    <script type="text/javascript" src="js/jquery.nivo.slider.pack.js"></script>
    <style>
        h2 {
            padding-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
    </style>
</head>
<body>
    <h1>Shoe Shop Record System</h1>
    <div id="slider-wrapper">
        <div id="slider" class="nivoSlider">
            <img src="images/slider/s1.jpg" alt=""/>
            <img src="images/slider/s2.jpg" alt=""/>
            <img src="images/slider/s3.jpg" alt=""/>
            <img src="images/slider/s4.jpg" alt=""/>
        </div>
        <div id="htmlcaption" class="nivo-html-caption">
            <strong>This</strong> is an example of a <em>HTML</em> caption with <a href="#">a link</a>.
        </div>
    </div>

    <h2>Popular Shoes</h2>
    <div id="popular-shoes">
        <!-- Daftar sepatu akan ditampilkan di sini -->
    </div>

    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();

        // Lakukan AJAX request untuk mengambil data sepatu populer
        $.ajax({
            url: 'fetch_popular_shoes.php',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data.error) {
                    $('#popular-shoes').html('<p>' + data.error + '</p>');
                } else if (data.length > 0) {
                    var html = '<ul>';
                    data.forEach(function(shoe) {
                        html += '<li>';
                        html += '<img src="images/product/' + shoe.picture + '" alt="' + shoe.name + '" width="100">';
                        html += '<h3>' + shoe.name + '</h3>';
                        html += '<p>Price: ' + shoe.price + '</p>';
                        html += '<p>Size: ' + shoe.size + '</p>';
                        html += '<p>Stock: ' + shoe.stock + '</p>';
                        html += '<p>' + shoe.comment + '</p>';
                        html += '</li>';
                    });
                    html += '</ul>';
                    $('#popular-shoes').html(html);
                } else {
                    $('#popular-shoes').html('<p>No popular shoes found.</p>');
                }
            },
            error: function() {
                $('#popular-shoes').html('<p>Error retrieving popular shoes.</p>');
            }
        });
    });
    </script>

    <h2>Search Shoes by Category</h2>
    <form id="category-form" method="post">
        <label for="category">Choose a category:</label>
        <select id="category" name="category">
            <option value="1">Formal</option>
            <option value="3">Slip-on</option>
            <option value="4">Flat</option>
            <option value="5">Heels</option>
            <option value="6">Sneakers</option>
            <option value="7">Wedges</option>
        </select>
        <input type="submit" value="Search">
    </form>

    <div id="shoe-details">
        <!-- Detail sepatu akan ditampilkan di sini -->
    </div>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $categoryId = $_POST['category'];

        // Koneksi ke database
        $conn = new mysqli('localhost', 'root', '', 'shoes-store');

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Panggil prosedur yang sudah dibuat
        $sql = "CALL GetShoeDetailsByCategory($categoryId)";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<h2>Shoe Details</h2>";
            echo "<table border='1'>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Category ID</th>
                        <th>Price</th>
                        <th>Picture</th>
                        <th>Size</th>
                        <th>Stock</th>
                        <th>Comment</th>
                        <th>Popularity</th>
                    </tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['categories_id']}</td>
                        <td>{$row['price']}</td>
                        <td><img src='images/product/{$row['picture']}' alt='{$row['name']}' width='50'></td>
                        <td>{$row['size']}</td>
                        <td>{$row['stock']}</td>
                        <td>{$row['comment']}</td>
                        <td>{$row['popularity']}</td>
                    </tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No shoes found in this category.</p>";
        }

        $conn->close();
    }
    ?>

</body>
</html>
