<?php
// Sertakan file koneksi ke database
include_once 'dbconection.php';

// Query untuk mengambil data customers
$sql = "SELECT * FROM customers";
$stmt = $dbh->query($sql);

// CSS Style untuk tabel
echo '<style>
        /* Aturan CSS untuk menyesuaikan tampilan tabel */
        .container {
            margin-top: 50px;
            width: 80%;
            margin: 0 auto;
        }
        .table {
            font-size: 16px;
            width: 100%;
            border-collapse: collapse;
        }
        .table th,
        .table td {
            color: #000; /* Warna font hitam */
            border: 1px solid #ddd; /* Garis tepi */
            padding: 8px;
            text-align: left;
        }
        .table th {
            background-color: #f2f2f2; /* Warna latar belakang header */
        }
        .table-striped tbody tr:nth-child(odd) {
            background-color: #f9f9f9; /* Warna latar belakang setiap baris ganjil */
        }
        .table-striped tbody tr:nth-child(even) {
            background-color: #fff; /* Warna latar belakang setiap baris genap */
        }
    </style>';

// Cek apakah ada data customers
if ($stmt->rowCount() > 0) {
    ?>
    <div class="container">
        <h1>Customers</h1>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <!-- Tambahkan kolom lain jika perlu -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Loop untuk menampilkan data customers
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['name']; ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php echo $row['phone']; ?></td>
                            <!-- Tambahkan kolom lain jika perlu -->
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
} else {
    // Tampilkan pesan jika tidak ada data customers
    echo "<div class='container'><p>No customers found.</p></div>";
}
?>

<!-- Button untuk menampilkan detail pelanggan beserta informasi pembelian terbaru mereka -->
<div class="container" style="margin-top: 50px;">
    <form action="view_customer_purchases.php" method="get">
        <button type="submit" class="btn btn-primary">View Customer purchases</button>
    </form>
</div>

<!-- Button untuk menampilkan email pelanggan untuk kategori tertentu -->
<div class="container" style="margin-top: 50px;">
    <form action="get_customer_emails_by_category.php" method="get">
        <label for="category_id">Category ID:</label>
        <input type="number" id="category_id" name="category_id" required>
        <button type="submit" class="btn btn-primary">Show Customer Emails</button>
    </form>
</div>

<?php
// Sertakan file koneksi ke database
include_once 'dbconection.php';

// Panggil stored procedure GetCustomerPurchaseSummary
$sql = "CALL GetCustomerPurchaseSummary(:customer_id)";
$stmt = $dbh->prepare($sql);

// Bind parameter
$customer_id = 1; // Ganti dengan ID pelanggan yang diinginkan
$stmt->bindParam(':customer_id', $customer_id, PDO::PARAM_INT);

// Eksekusi stored procedure
$stmt->execute();

// Ambil hasil dari stored procedure
$result = $stmt->fetch(PDO::FETCH_ASSOC);

// Output hasil dalam bentuk tabel
echo "<div class='container' style='padding: 50px;'>";
echo "<h2>Customer Purchase Summary</h2>";
echo "<table class='table'>";
echo "<thead>";
echo "<tr>";
echo "<th>Total Purchase Amount</th>";
echo "<th>Total Payment Amount</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";
echo "<tr>";
echo "<td>" . $result['total_purchase_amount'] . "</td>";
echo "<td>" . $result['total_payment_amount'] . "</td>";
echo "</tr>";
echo "</tbody>";
echo "</table>";
echo "</div>";

// Tutup koneksi
$dbh = null;
?>
